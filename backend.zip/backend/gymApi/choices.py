MembershipType = [
    ('monthly' , 'Monthly') ,
    ('quarterly' , 'Quarterly'),
    ('annual' , 'Annual')
]
MembershipStatus = [
    ('active', 'Active'),
    ('expired', 'Expired'),
    ('suspended', 'Suspended'),
]